
             sudo yum update -y
            sudo yum upgrade upgrade -y
            sudo yum install https://www.elrepo.org/elrepo-release-7.el7.elrepo.noarch.rpm -y
            sudo yum update -y

             yum --enablerepo=elrepo* install kernel-lt -y
             

 
